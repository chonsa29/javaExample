package test1;

public class Problem1 {
	public static void main(String[] args) {
		String name = "홍길동";
		int age = 30;
		String addr = "인천";
		
		System.out.println(name+"의 나이는 " + age +", 주소는 " + addr+ " 입니다.");
	}
}
