package test1;

public class Problem5 {
	public static void main(String[] args) {
		for(int i = 1;i<=30;i++) {
			if(i < 10 || i > 19) System.out.println(i);;
		}
	}
}
